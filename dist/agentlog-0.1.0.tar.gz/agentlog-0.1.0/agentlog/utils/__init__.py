"""Shared utilities for agentlog."""
